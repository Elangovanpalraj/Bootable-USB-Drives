Python 3.10.10 (tags/v3.10.10:aad5f6a, Feb  7 2023, 17:20:36) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
data= lambda a,b,c: a+b+c
print(add(2,2,6))
Traceback (most recent call last):
  File "<pyshell#1>", line 1, in <module>
    print(add(2,2,6))
NameError: name 'add' is not defined
data= lambda a,b,c: a+b+c
print(data(2,2,6))
10
a = [2,4,6,8,]
from i in a:
    
SyntaxError: invalid syntax
from i in a:
    
SyntaxError: invalid syntax
from i in a():
    
SyntaxError: invalid syntax
for i in a():
    print(i,*5)

    
Traceback (most recent call last):
  File "<pyshell#10>", line 1, in <module>
    for i in a():
TypeError: 'list' object is not callable
for i in a():
    print(i*5)

    
Traceback (most recent call last):
  File "<pyshell#12>", line 1, in <module>
    for i in a():
TypeError: 'list' object is not callable
>>> for i in a:
...     print(i*5)
... 
...     
10
20
30
40
>>> n ['one','helle','treub']
Traceback (most recent call last):
  File "<pyshell#15>", line 1, in <module>
    n ['one','helle','treub']
NameError: name 'n' is not defined
>>> n = ['one','helle','treub']
>>> de = map(len lambda x: n)
SyntaxError: invalid syntax. Perhaps you forgot a comma?
>>> de = map(len lambda x: n)
SyntaxError: invalid syntax. Perhaps you forgot a comma?
>>> de = map(len ,lambda x: n)
Traceback (most recent call last):
  File "<pyshell#19>", line 1, in <module>
    de = map(len ,lambda x: n)
TypeError: 'function' object is not iterable
>>> de = list(map(len ,lambda x: n))
Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    de = list(map(len ,lambda x: n))
TypeError: 'function' object is not iterable


# filter
a = [3,4,5,6]
b=[3,4,6]
