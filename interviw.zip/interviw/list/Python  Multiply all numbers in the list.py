# Python | Multiply all numbers in the list
# -----------------------------------------\n
'''
Input :  list1 = [1, 2, 3]
Output : 6
Explanation: 1*2*3=6

Input : list1 = [3, 2, 4]
Output : 24
'''
# type
# ---\n
# Using Traversal
# Using numpy.prod()
# Using lambda function
# Using Math Library
# Using mul() function
# Using traversal by index
# Using For loop
# Using itertools.accumulate()
# Using recursive function
# --------------------------\n
# Using Traversal
# ---------------\n
# Python program to multiply all values in the
# list using traversal
 
 
def multiplyList(myList):
 
    # Multiply elements one by one
    result = 1
    for x in myList:
        result = result * x
    return result
 
 
# Driver code
list1 = [1, 2, 3]
list2 = [3, 2, 4]
print(multiplyList(list1))
print(multiplyList(list2))
print(' ')
# the list using numpy.prod()
# ---------------------------\n
# Python3 program to multiply all values in the
# list using numpy.prod()
 
import numpy
list1 = [1, 2, 3]
list2 = [3, 2, 4]
 
# using numpy.prod() to get the multiplications
result1 = numpy.prod(list1)
result2 = numpy.prod(list2)
print(result1)
print(result2)
print(' ')
# the list using lambda function
# -----------------------------\n

# Python3 program to multiply all values in the
# list using lambda function and reduce()
from functools import reduce
list1 = [1, 2, 3]
list2 = [3, 2, 4]
 
result1 = reduce((lambda x, y: x * y), list1)
result2 = reduce((lambda x, y: x * y), list2)
print(result1)
print(result2)
print(' ')
# the list using prod function of math library
# -------------------------------------------\n
# Python3 program to multiply all values in the
# list using math.prod
import math
list1 = [1, 2, 3] 
list2 = [3, 2, 4]
 
result1 = math.prod(list1)
result2 = math.prod(list2)
print(result1)
print(result2)
print(' ')
# the list using mul() function of operator module.
# -----------------------------------------------\n
# Python 3 program to multiply all numbers in
# the given list by importing operator module
 
from operator import*
list1 = [1, 2, 3]
m = 1
for i in list1:
  # multiplying all elements in the given list 
  # using mul function of operator module
    m = mul(i, m)
# printing the result
print(m)
print(' ')
# the list using For Loop
# -----------------------\n
def multiply_list(list1):
    # Initialize product to 1
    product = 1
     
    # Iterate through each element in the list
    for element in list1:
        product *= element
     
    return product
 
# Example
list1 = [1, 2, 3, 4, 5]
result = multiply_list(list1)
print(result)
print(' ')
#  the list using traversal by index
# ---------------------------------\n
# Python program to multiply all values in the
# list using traversal
 
def multiplyList(myList) :
     
    # Multiply elements one by one
    result = 1
    for i in range(0,len(myList)):
        result = result * myList[i]
    return result
     
# Driver code
list1 = [1, 2, 3]
list2 = [3, 2, 4]
print(multiplyList(list1))
print(multiplyList(list2))
print(' ')
# the list using itertools.accumulate
# --------------------------------\n
# Python3 program to multiply all values in the
# list using lambda function and accumulate()
from itertools import accumulate
list1 = [1, 2, 3]
list2 = [3, 2, 4]
 
result1 = list(accumulate(list1, (lambda x, y: x * y)))
result2 = list(accumulate(list2, (lambda x, y: x * y)))
print(result1[-1])
print(result2[-1])
print(' ')
# the list using the recursive function
# --------------------------------------\n
def product_recursive(numbers):
    # base case: list is empty
    if not numbers:
        return 1
    # recursive case: multiply first element by product of the rest of the list
    return numbers[0] * product_recursive(numbers[1:])
list1 = [1, 2, 3]
product = product_recursive(list1)
print(product)  # Output: 6
 
list2 = [3, 2, 4]
product = product_recursive(list2)
print(product)  # Output: 24
print(' ')
# the list Using reduce() and the mul() function
# ----------------------------------------------\n
from functools import reduce
from operator import mul
 
list1 = [1, 2, 3]
result = reduce(mul, list1)
 
print(result)
print(' ')
# ---------------------------------------------=----------\n











































































