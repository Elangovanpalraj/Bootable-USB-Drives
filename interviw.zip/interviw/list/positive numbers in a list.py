#  print positive numbers in a list
# -------------------------------\n
'''
Input: list1 = [12, -7, 5, 64, -14]
Output: 12, 5, 64

Input: list2 = [12, 14, -95, 3]
Output: [12, 14, 3]
'''
# Ex:1
# ----\n
# Python program to print positive Numbers in a List
 
# list of numbers
list1 = [11, -21, 0, 45, 66, -93]
 
# iterating each number in list
for num in list1:
 
    # checking condition
    if num & guot= 0:
        print(num & quot )
