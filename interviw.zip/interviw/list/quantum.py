from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, Aer, execute

q = QuantumRegister(2,"q0")
c = ClassicalRegister(2,"c0")

qc = QuantumCircuit(q,c)

qc.h(q[0]) #Superposition
qc.cx(q[0],q[1]) #Entanglement

#Measurement
qc.measure(q,c)
display(qc.draw('mpl'))

job = execute(qc,Aer.get_backend('qasm_simulator'), shots = 1000)
counts = job.result().get_counts(qc)

print(counts)
