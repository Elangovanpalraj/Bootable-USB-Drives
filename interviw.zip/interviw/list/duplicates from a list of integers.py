# duplicates from a list of integers
# -------------------------------\n
'''
Input : list = [10, 20, 30, 20, 20, 30, 40, 50, -20, 60, 60, -20, -20]
Output : output_list = [20, 30, -20, 60]
Input :  list = [-1, 1, -1, 8]
Output : output_list = [-1]
'''
# Method 1: Using the Brute Force
# ----------------------------\n
def Repeat(x):
    _size = len(x)
    repeated = []
    for i in range(_size):
        k = i + 1
        for j in range(k, _size):
            if x[i] == x[j] and x[i] not in repeated:
                repeated.append(x[i])
    return repeated
 
# Driver Code
list1 = [10, 20, 30, 20, 20, 30, 40, 
         50, -20, 60, 60, -20, -20]
print (Repeat(list1))
print(' ')
# Method 2: Using a single for loop
# ---------------------------------\n
lis = [1, 2, 1, 2, 3, 4, 5, 1, 1, 2, 5, 6, 7, 8, 9, 9]
 
uniqueList = []
duplicateList = []
 
for i in lis:
    if i not in uniqueList:
        uniqueList.append(i)
    elif i not in duplicateList:
        duplicateList.append(i)
 
print(duplicateList)
print(' ')
# Method 3: Using Counter() function from collection module
# ------------------------------------------------------\n

from collections import Counter
 
l1 = [1,2,1,2,3,4,5,1,1,2,5,6,7,8,9,9]
d = Counter(l1)
print(d)
 
new_list = list([item for item in d if d[item]>1])
print(new_list)
print(' ')
# Method 4: Using count() method
# -----------------------------\n
list = [1, 2, 1, 2, 3, 4, 5, 1, 1, 2, 5, 6, 7, 8, 9, 9]
 
new = []  # defining output list
 
# condition for reviewing every
# element of given input list
for a in list:
 
     # checking the occurrence of elements
    n = list.count(a)
 
    # if the occurrence is more than
    # one we add it to the output list
    if n > 1:
 
        if new.count(a) == 0:  # condition to check
 
            new.append(a)
 
print(new)
 
# This code is contributed by Himanshu Khune
print(' ')
'''
# Method 5: Using list comprehension method
# ---------------------------------------\n
def duplicate(input_list):
    return list(set([x for x in input_list if input_list.count(x) > 1]))
 
if __name__ == '__main__':
    input_list = [1, 2, 1, 2, 3, 4, 5, 1, 1, 2, 5, 6, 7, 8, 9, 9]
    print(duplicate(input_list))
 
# This code is contributed by saikot
print(' ')
'''
# Method 6: Using list-dictionary approach (without any inbuild count function)
# ------------------------------------------------------------\n
def duplicate(input_list):
    new_dict, new_list = {}, []
 
    for i in input_list:
        if not i in new_dict:
            new_dict[i] = 1
        else:
            new_dict[i] += 1
 
    for key, values in new_dict.items():
        if values > 1:
            new_list.append(key)
 
    return new_list
 
if __name__ == '__main__':
    input_list = [1, 2, 1, 2, 3, 4, 5, 1, 1, 2, 5, 6, 7, 8, 9, 9]
    print(duplicate(input_list))
 
# This code is contributed by saikot
print(' ')

# Method 7: Using in, not in operators and count() method
# -------------------------------------------------------\n
lis = [1, 2, 1, 2, 3, 4, 5, 1, 1, 2, 5, 6, 7, 8, 9, 9]
x = []
y = []
for i in lis:
    if i not in x:
        x.append(i)
for i in x:
    if lis.count(i) > 1:
        y.append(i)
print(y)
print(' ')
'''
# Method 8: Using enumerate function
# ---------------------------------\n
input_list = [1, 2, 1, 2, 3, 4, 5, 1, 1, 2, 5, 6, 7, 8, 9, 9]
print(list(set([x for i,x in enumerate(input_list) if input_list.count(x) > 1])))
print(' ')
'''
# Method 9: Using operator.countOf() method
# ------------------------------------------\n
import operator as op
# program to print duplicate numbers in a given list
# provided input
list = [1, 2, 1, 2, 3, 4, 5, 1, 1, 2, 5, 6, 7, 8, 9, 9]
 
new = []  # defining output list
 
# condition for reviewing every
# element of given input list
for a in list:
 
     # checking the occurrence of elements
    n = op.countOf(list, a)
 
    # if the occurrence is more than
    # one we add it to the output list
    if n > 1:
 
        if op.countOf(new, a) == 0:  # condition to check
 
            new.append(a)
 
print(new)
 
# This code is contributed by vikkycirus
print(' ')

# Method 10 : Using operator.countOf(),in and not in operators
# ------------------------------------------------------------\n
lis = [1, 2, 1, 2, 3, 4, 5, 1, 1, 2, 5, 6, 7, 8, 9, 9]
x = []
y = []
import operator
for i in lis:
    if i not in x:
        x.append(i)
for i in x:
    if operator.countOf(lis,i) > 1:
        y.append(i)
print(y)
print(' ')
# Method 11 : Using numpy:
# ------------------------\n
import numpy as np
 
l1 = [1,2,1,2,3,4,5,1,1,2,5,6,7,8,9,9]
 
unique, counts = np.unique(l1, return_counts=True)
new_list = unique[np.where(counts > 1)]

print(new_list)
#This code is contributed by Rayudu
print(' ')
# ----------------------------------------------------------\n 





















































































