#Python Program to Find Largest Number in a List
# -----------------------------------------------\n
'''
Input : list1 = [10, 20, 4]
Output : 20
'''
# Find Largest Number in a List with Native Example
# -------------------------------------------------\n
# Python program to find largest
# number in a list
 
# list of numbers
list1 = [10, 20, 4, 45, 99]
 
# sorting the list
list1.sort()
 
# printing the last element
print("Largest element is:", list1[-1])
print(' ')
# List Using max() method
# ----------------------\n
# Python program to find largest
# number in a list
 
# List of numbers
list1 = [10, 20, 4, 45, 99]
 
# Printing the maximum element
print("Largest element is:", max(list1))
print(' ')
#  the max list element on inputs provided by user
# ---------------------------------------------\n
# Python program to find largest
# number in a list
 
# Creating an empty list
list1 = []
 
# asking number of elements to put in list
num = int(input("Enter number of elements in list: "))
 
# Iterating till num to append elements in list
for i in range(1, num + 1):
    ele = int(input("Enter elements: "))
    list1.append(ele)
 
# Printing maximum element
print("Largest element is:", max(list1))
print(' ')
# List Without using built-in functions
# ------------------------------------\n

# Python program to find largest
# number in a list
 
 
def myMax(list1):
 
    # Assume first number in list is largest
    # initially and assign it to variable "max"
    max = list1[0]
# Now traverse through the list and compare
    # each number with "max" value. Whichever is
    # largest assign that value to "max'.
    for x in list1:
        if x > max:
            max = x
 
    # after complete traversing the list
    # return the "max" value
    return max
 
 
# Driver code
list1 = [10, 20, 4, 45, 99]
print("Largest element is:", myMax(list1))
print(' ')
# List Using the lambda function
# --------------------------------\n
# python code to print largest element in the list
 
lst = [20, 10, 20, 4, 100]
print(max(lst, key=lambda value: int(value)) )
print(' ')
# List Using reduce function
# ---------------------------\n
from functools import reduce
lst = [20, 10, 20, 4, 100]
largest_elem = reduce(max, lst)
print(largest_elem)
print(' ')
# List Using recursion
# ------------------\n

# Function to find the largest element in the list
def FindLargest(itr, ele, list1):
 
  # Base condition
    if itr == len(list1):
        print("Largest element in the list is: ", ele)
        return
 
      # Check max condition
    if ele < list1[itr]:
        ele = list1[itr]
 
        # Recursive solution
    FindLargest(itr+1, ele, list1)
 
    return
 
  # input list
list1 = [2, 1, 7, 9, 5, 4]
 
FindLargest(0, list1[0], list1)
print(' ')
# List Using heapq.nlargest()
# --------------------------\n
import heapq
 
# list of numbers
list1 = [10, 20, 4, 45, 99]
 
# finding the largest element using heapq.nlargest()
largest_element = heapq.nlargest(1, list1)[0]
 
# printing the largest element
print("Largest element is:", largest_element)
print(' ')
# List Using np.max() method
# --------------------------\n
import numpy as np
 
# given list
list1 = [2, 7, 5, 64, 14]
 
# converting list to numpy array
arr = np.array(list1)
 
# finding largest numbers using np.max() method
num = arr.max()
 
# printing largest number
print(num)
print(' ')
# ---------------------------------------------------\n



































































































