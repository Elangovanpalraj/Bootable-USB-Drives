# python interchange frist and last elements in list

# swap function

def swapList(newlist):
    size = len (newlist)

    # swapping

    temp = newlist[0]
    newlist[0] = newlist[size - 1]
    newlist[size - 1] = temp

    return newlist

newlist = [12,35,9,56,24]

print(swapList(newlist))

print('# ---------------------------------------------------------------------\n')

def swaplist(newlist):
    newlist[0],newlist[-1] = newlist

    return newlist

newlist = [12,35,9,56,24]
print(swapList(newlist))

print('# -------------------------------------------------------------------------\n')

def swaplist(list):
    get = list[0],list[-1]
    list[0],list[-1] = get
    
    return list

newlist = [12,35,9,56,24]
print(swaplist(newlist))

print('# ----------------------------------------------------------------------------\n')

# using of * operand

list = [1,2,3,4]
*a,b,c = list


print(a)
print(b)
print(c)

print('# ---------------------------------------------------------------------------------\n')

# swapping

def swaplist(list):
    start,*middle,end = list
    list = [end,*middle,start]

    return list

newlist = [12,35,9,56,24]
print(swaplist(newlist))

print('# -----------------------------------------------------------------------------------------\n')

def swaplist (list):
    first = list.pop(0)
    last = list.pop(-1)

    list.insert(0,last)
    list.append(first)

    return list

newlist = [12,35,9,56,24]
print(swaplist(newlist))

print('# ----------------------------------------------------------------------------------------\n')

# using slicing

def swap_first_last_3(lst):
    if len(lst) >= 2:
        lst = lst [-1:] + lst [1:-1] + lst [:1]
        
        return lst

inp = [12,35,9,56,24]

print("the original inputn is :",inp)

result = swap_first_last_3(inp)

print("the output after swap first and last is :",result)
print('# ----------------------------------------------------------------------------------------\n')
    


















        
