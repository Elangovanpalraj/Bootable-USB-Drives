# Remove empty tuples from a list
# -------------------------------\n
'''
Input : tuples = [(), (‘ram’,’15’,’8′), (), (‘laxman’, ‘sita’), (‘krishna’, ‘akbar’, ’45’), (”,”),()]
Output : [(‘ram’, ’15’, ‘8’), (‘laxman’, ‘sita’), (‘krishna’, ‘akbar’, ’45’), (”, ”)]

Input : tuples = [(”,”,’8′), (), (‘0′, ’00’, ‘000’), (‘birbal’, ”, ’45’), (”), (),  (”,”),()]
Output : [(”, ”, ‘8’), (‘0′, ’00’, ‘000’), (‘birbal’, ”, ’45’), (”, ”)]

'''
# List Comprehension
# -------------------\n

def Remove(tuples):
    tuples = [t for t in tuples if t]
    return tuples
 
# Driver Code
tuples = [(), ('ram','15','8'), (), ('laxman', 'sita'), 
          ('krishna', 'akbar', '45'), ('',''),()]
print(Remove(tuples))
print(' ')
# Method 2: Using the filter() method
# ------------------------------------\n
def Remove(tuples):
    tuples = filter(None, tuples)
    return tuples
 
# Driver Code
tuples = [(), ('ram','15','8'), (), ('laxman', 'sita'), 
          ('krishna', 'akbar', '45'), ('',''),()]
print (Remove(tuples))
print(' ')
# Methods filter 1
# ---------\n
def Remove(tuples):
    tuples = filter(None, tuples)
    return tuples
 
 
# Driver Code
tuples = [(), ('ram', '15', '8'), (), ('laxman', 'sita'),
          ('krishna', 'akbar', '45'), ('', ''), ()]
print(Remove(tuples))
print(' ')
# Method #3 : Using len() method
# -------------------------------\n
 
def Remove(tuples):
    for i in tuples:
        if(len(i) == 0):
            tuples.remove(i)
    return tuples
 
 
# Driver Code
tuples = [(), ('ram', '15', '8'), (), ('laxman', 'sita'),
          ('krishna', 'akbar', '45'), ('', ''), ()]
print(Remove(tuples))
print(' ')
# Method #4 : Using == operator
# ----------------------------\n
def Remove(tuples):
    for i in tuples:
        if(i==()):
            tuples.remove(i)
    return tuples
# Driver Code
tuples = [(), ('ram','15','8'), (), ('laxman', 'sita'),
        ('krishna', 'akbar', '45'), ('',''),()]
print(Remove(tuples))
print(' ')
# Method: Using enumerate function
# ------------------------------\n
tuples = [(), ('ram', '15', '8'), (), ('laxman', 'sita'),
          ('krishna', 'akbar', '45'), ('', ''), ()]
res = [t for i, t in enumerate(tuples) if t]
print(res)
print(' ')
# Method: Using while and in operator
# ----------------------------------\n
def Remove(tuples):
    while () in tuples:
        tuples.remove(());
    return tuples
 
# Driver Code
tuples = [(), ('ram','15','8'), (), ('laxman', 'sita'),
        ('krishna', 'akbar', '45'), ('',''),()]
print (Remove(tuples))
print(' ')
# Method : Using str(), len() and find() method
# --------------------------------------------\n
def Remove(tuples):
    for i in tuples:
        if(str(i).find("()") != -1 and len(str(i)) == 2):
            tuples.remove(i)
    return tuples
 
 
# Driver Code
tuples = [(), ('ram', '15', '8'), (), ('laxman', 'sita'),
          ('krishna', 'akbar', '45'), ('', ''), ()]
print(Remove(tuples))
print(' ')
# Method: Using lambda functions
# -----------------------------\n
tuples = [(), ('ram', '15', '8'), (), ('laxman', 'sita'),
          ('krishna', 'akbar', '45'), ('', ''), ()]
 
tuples = list(filter(lambda x: len(x) > 0, tuples))
print(tuples)
print(' ')
# Method : Using  list comprehension , len() method:
# -------------------------------------------------\n
def remove_empty_tuples(tuples):
    return [t for t in tuples if len(t) > 0]
 
tuples = [(), ('ram','15','8'), (), ('laxman', 'sita'),
          ('krishna', 'akbar', '45'), ('',''),()]
print(remove_empty_tuples(tuples))
#This code is contributed by Edula Vinay Kumar Reddy
print(' ')
# Method: Using Recursion method
# ------------------------------\n
def remove_empty_tuples(start,oldlist,newlist):
  if start==len(oldlist):  #base condition 
    return newlist
  if oldlist[start]==():  #checking the element is empty tuple or not
    pass
  else:
    newlist.append(oldlist[start])   #appending non empty tuple element to newlist
  return remove_empty_tuples(start+1,oldlist,newlist)  #recursive function call
 
 
tuples = [(), ('ram','15','8'), (), ('laxman', 'sita'),
          ('krishna', 'akbar', '45'), ('',''),()]
#print('The original list: ',tuples)
print(remove_empty_tuples(0,tuples,[]))
print(' ')
# Method 5: Using itertools.filterfalse()
# -----------------------------------\n

import itertools  # import the itertools module
 
def Remove(tuples):
    tuples = list(itertools.filterfalse(lambda x: x == (), tuples))  # remove empty tuples using filterfalse from itertools
    return tuples
 
# Driver code
tuples = [(), ('ram','15','8'), (), ('laxman', 'sita'),
          ('krishna', 'akbar', '45'), ('',''),()]  # define the input list of tuples
print(Remove(tuples))  # call the Remove function and print the output
print(' ')
# Method 6: Using reduce():
# -------------------------\n
from functools import reduce
 
# defining lambda function to remove empty tuples
remove_empty = lambda lst, val: lst + [val] if val != () else lst
 
tuples = [(), ('ram','15','8'), (), ('laxman', 'sita'),
          ('krishna', 'akbar', '45'), ('',''),()]
 
# using reduce to remove empty tuples
result = reduce(remove_empty, tuples, [])
 
# printing final result
print("The original list is : " + str(tuples))
print("The list after removing empty tuples : " + str(result))
#This code is contributed by Rayudu.
print(' ')
# ---------------------------------------------------------\n























































































































