# Cloning or Copying a list
# -------------------------\n
# Types
# -----\n
# Using the slicing technique 
# Using the extend() method 
# List copy using =(assignment operator)
# Using the method of Shallow Copy 
# Using list comprehension 
# Using the append() method 
# Using the copy() method 
# Using the method of Deep Copy
# Using the map method 
# Using slice() function
# -----------------------------------------------------------\n
# Using the slicing technique
# --------------------------\n
def Cloning(li1):
    li_copy = li1[:]
    return li_copy
 
 
# Driver Code
li1 = [4, 8, 2, 10, 15, 18]
li2 = Cloning(li1)
print("Original List:", li1)
print("After Cloning:", li2)
print(' ')
# Using Python extend() method
# --------------------------\n
def Cloning(li1):
    li_copy = []
    li_copy.extend(li1)
    return li_copy
 
 
# Driver Code
li1 = [4, 8, 2, 10, 15, 18]
li2 = Cloning(li1)
print("Original List:", li1)
print("After Cloning:", li2)
print(' ')

# Using Assignment Operator
# ------------------------\n
def Cloning(li1): 
    li_copy = li1
    return li_copy 
   
# Driver Code 
li1 = [4, 8, 2, 10, 15, 18] 
li2 = Cloning(li1) 
print("Original List:", li1) 
print("After Cloning:", li2)
print(' ')
# Using Shallow Copy in Python
# ----------------------------\n

import copy
   
# initializing list 1 
li1 = [1, 2, [3,5], 4]
   
# using copy for shallow copy  
li2 = copy.copy(li1)
 
print(li2)
print(' ')
# Using List Comprehension
# ------------------------\n
def Cloning(li1): 
    li_copy = [i for i in li1] 
    return li_copy 
   
# Driver Code 
li1 = [4, 8, 2, 10, 15, 18] 
li2 = Cloning(li1) 
print("Original List:", li1) 
print("After Cloning:", li2)
print(' ')
# Python append() to Clone or Copy a list
# ----------------------------------\n
def Cloning(li1): 
    li_copy =[] 
    for item in li1: li_copy.append(item) 
    return li_copy 
   
# Driver Code 
li1 = [4, 8, 2, 10, 15, 18] 
li2 = Cloning(li1) 
print("Original List:", li1) 
print("After Cloning:", li2)
print(' ')
# Using the copy() method
# ---------------------------\n
def Cloning(li1): 
    li_copy =[] 
    li_copy = li1.copy() 
    return li_copy 
   
# Driver Code 
li1 = [4, 8, 2, 10, 15, 18] 
li2 = Cloning(li1) 
print("Original List:", li1) 
print("After Cloning:", li2)
print(' ')
# Using the method of Deep Copy
# ---------------------------\n
import copy
   
# initializing list 1 
li1 = [1, 2, [3,5], 4]
 
# using deepcopy for deepcopy  
li3 = copy.deepcopy(li1) 
print(li3)
print(' ')
#  Using Enumerate Function
# ----------------------\n
lst = [4, 8, 2, 10, 15, 18] 
li_copy = [i for a,i in enumerate(lst)] 
print("Original List:", lst) 
print("After Cloning:", li_copy)
print(' ')
# using Map Function
# ------------------\n
lst = [4, 8, 2, 10, 15, 18]
li_copy = map(int, lst)
print("Original List:", lst)
print("After Cloning:", *li_copy)
print(' ')
# Using slice() function
# ---------------------\n
lst = [4, 8, 2, 10, 15, 18]
li_copy = lst[slice(len(lst))]
print("Original List:", lst)
print("After Cloning:", li_copy)
 
# This code is contributed by Pushpesh Raj.
print(' ')
# Using the deque() function
# ---------------------\n
from collections import deque
 
original_list = [4, 8, 2, 10, 15, 18]
 
copied_list = deque(original_list)
copied_list = list(copied_list)
 
print("Original List:", original_list)
 
print("After Cloning:", copied_list)
print(' ')
# List Using reduce()
# ---------------\n
from functools import reduce
 
def clone_list(li1):
    return reduce(lambda x, y: x + [y], li1, [])
 
# Driver Code
li1 = [4, 8, 2, 10, 15, 18]
li2 = clone_list(li1)
print("Original List:", li1)
print("After Cloning:", li2)
print(' ')
# ---------------------------------------------------------\n



















































































































