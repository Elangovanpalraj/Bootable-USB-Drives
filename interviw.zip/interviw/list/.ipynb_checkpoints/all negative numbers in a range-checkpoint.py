# all negative numbers in a range
# -------------------------------\n
'''
Input: a = -4, b = 5
Output: -4, -3, -2, -1

Input: a = -3, b= 4
Output: -3, -2, -1
'''
#  Print all the negative numbers using a single-line solution
# ------------------------------------------------------------\n
def negativenumbers(a,b): 
  # Checking condition for negative numbers 
  # single line solution 
  out=[i for i in range(a,b+1) if i<0] 
  # print the all negative numbers
  print(*out) 
 
# driver code 
# a -> start range 
a=-4
# b -> end range 
b=5
negativenumbers(a,b)
print(' ')
# methods 1
# ---------\n
start, end = -4, 19
 
# iterating each number in list
for num in range(start, end + 1):
     
    # checking condition
    if num < 0:
        print(num, end = " ")

print(' ')
# Taking range limit from user input 
# -------------------------------\n
start = int(input("Enter the start of range: "))
end = int(input("Enter the end of range: "))
 
# iterating each number in list
for num in range(start, end + 1):
     
    # checking condition
    if num < 0:
        print(num, end = " ")
print(' ')
# Using lambda function
# --------------------\n
a=-4;b=5
li=[]
for i in range(a,b):
    li.append(i)
# printing negative numbers using the lambda function
negative_num = list(filter(lambda x: (x<0),li))  
print(negative_num)
print(' ')
# Using enumerate function
# -----------------------\n
a=-4;b=5;l=[]
for i in range(a,b+1):
  l.append(i)
print([a for j,a in enumerate(l) if a<0])
print(' ')
#  Using list comprehension
# ------------------------\n
a=-4;b=5
print([i for i in range(a,b+1) if i<0])
print(' ')
# Using pass
# ----------\n
a=-4;b=5
for i in range(a,b+1):
  if i>=0:
    pass
  else:
    print(i,end=" ")
print(' ')
#  Using recursion
# ---------------\n
def PrintNegative(itr,end):
  if itr == end: #Base Condition
    return
  if itr < 0:  #checking Negative or not
    print(itr,end=" ")
  PrintNegative(itr+1,end)  #Recursive function call
  return
a = -5
b = 5
PrintNegative(a,b)
print(' ')
# Using numpy.arange() and numpy.where():
# -----------------------------------\n
import numpy as np
 
# Taking input values for start and end of the range
start = -4
end = 5
 
# Creating an array using numpy.arange()
arr = np.arange(start, end+1)
 
# Filtering negative numbers using numpy.where()
neg_arr = arr[np.where(arr<0)]
 
# Printing the resulting array
print(neg_arr)
print(' ')
# -------------------------------------------------------------\n



























































































































































