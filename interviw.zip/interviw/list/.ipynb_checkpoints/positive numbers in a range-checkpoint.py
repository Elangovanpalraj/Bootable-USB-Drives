# positive numbers in a range
# -----------------------\n
'''
Input: start = -4, end = 5
Output: 0, 1, 2, 3, 4, 5 

Input: start = -3, end = 4
Output: 0, 1, 2, 3, 4
'''
# Example #1
# ---------\n
start, end = -4, 19
  
# iterating each number in list 
for num in range(start, end + 1): 
  
    # checking condition 
    if num >= 0: 
        print(num, end=" ")

print(' ')
# Taking range limit from user input
# ----------------------------------\n
start = int(input("Enter the start of range: ")) 
end = int(input("Enter the end of range: ")) 
  
# iterating each number in list 
for num in range(start, end + 1): 
  
    # checking condition 
    if num >= 0: 
        print(num, end=" ")

print(' ')
#  Using the lambda function
# -------------------------\n

a=-4;b=5 
li=[] 
for i in range(a,b+1): 
    li.append(i) 
# printing positive numbers using the lambda function 
positive_num = list(filter(lambda x: (x>=0),li))   
print(positive_num)
print(' ')
# Using the list comprehension
# --------------------------\n

a=-4;b=5
out=[i for i in range(a,b+1) if i>0] 
  # print the all positive numbers 
print(*out)
print(' ')
# Using enumerate function
# -----------------------\n
a=-4;b=5;l=[] 
for i in range(a,b+1): 
  l.append(i) 
print([a for j,a in enumerate(l) if a>=0])
print(' ')
# Using pass()
# -----------\n
a=-4;b=5 
for i in range(a,b+1): 
  if i<0: 
    pass 
  else: 
    print(i,end=" ")
print(' ')
# Using recursion
# --------------\n
def printPositives(start,end):   #defining recursive function to print positives 
  if start==end:return  #base condition 
  if start>=0:   #check for positive number 
    print(start,end=' ') 
  printPositives(start+1,end)  # recursive calling 
a,b=-5,10
printPositives(a,b) #function calling
print(' ')
#  Using filter() function:
# ----------------------\n
a = -4
b = 5
  
positive_nums = list(filter(lambda x: x >= 0, range(a, b+1))) 
print(positive_nums)
print(' ')



















































































































































































