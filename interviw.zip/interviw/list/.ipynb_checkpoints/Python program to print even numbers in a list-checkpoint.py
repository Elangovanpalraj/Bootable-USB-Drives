# print even numbers in a list
# -------------------------\n
'''
Input: list1 = [2, 7, 5, 64, 14]
Output: [2, 64, 14]
Input: list2 = [12, 14, 95, 3]
Output: [12, 14]
'''
# Method 1: Using for loop
# -----------------------\n
# Python program to print Even Numbers in a List
 
# list of numbers
list1 = [10, 21, 4, 45, 66, 93]
 
# iterating each number in list
for num in list1:
 
    # checking condition
    if num % 2 == 0:
        print(num, end=" ")

print(' ')
# Method 2: Using while loop
# -------------------------\n
# Python program to print Even Numbers in a List
 
# Initializing list and value
list1 = [10, 24, 4, 45, 66, 93]
num = 0
 
# Uing while loop
while(num < len(list1)):
 
    # Cecking condition
    if list1[num] % 2 == 0:
        print(list1[num], end=" ")
 
    # increment num
    num += 1

print(' ')
# Method 3: Using list comprehension
# ----------------------------------\n
# Python program to print even Numbers in a List
 
# Initializing list 
list1 = [10, 21, 4, 45, 66, 93]
 
# using list comprehension
even_nos = [num for num in list1 if num % 2 == 0]
 
print("Even numbers in the list: ", even_nos)
print(' ')
# Method 4: Using lambda expressions
# ---------------------------------\n
# Python program to print Even Numbers in a List
 
# list of numbers
list1 = [10, 21, 4, 45, 66, 93, 11]
 
 
# we can also print even no's using lambda exp.
even_nos = list(filter(lambda x: (x % 2 == 0), list1))
 
print("Even numbers in the list: ", even_nos)
print(' ')
# Method 5: Using Recursion
# -----------------------\n

# Python program to print
# even numbers in a list using recursion
 
 
def evennumbers(list, n=0):
 
    # base case
    if n == len(list):
        exit()
    if list[n] % 2 == 0:
        print(list[n], end=" ")
     
    # calling function recursively
    evennumbers(list, n+1)
 
# Initializing list  
list1 = [10, 21, 4, 45, 66, 93]
 
print("Even numbers in the list:", end=" ")
evennumbers(list1)
print(' ')
#  Method 6: Using enumerate function
# -----------------------------------\n
list1 = [2, 7, 5, 64, 14]
for a, i in enumerate(list1):
    if i % 2 == 0:
        print(i, end=" ")
print(' ')

# Method 7: Using pass
# -------------------\n
list1 = [2, 7, 5, 64, 14]
for i in list1:
    if (i % 2 != 0):
        pass
    else:
        print(i, end=" ")

print(' ')
# Method 8: Using numpy.array
# --------------------------\n
# Python code To print all even numbers
# in a given list using numpy array
import numpy as np
 
# Declaring Range
temp = [2, 7, 5, 64, 14]
li = np.array(temp)
 
# printing even numbers using numpy array
even_num = li[li % 2 == 0]
print(even_num)
print(' ')
# Method 9: Using not and Bitwise & operator
# -----------------------------------------\n
#python program to print all even no's in a list
#defining list with even and odd numbers 
list1=[39,28,19,45,33,74,56] 
#traversing list using for loop
for element in list1:
  if not element&1:  #condition to check even or not
    print(element,end=' ')

print(' ')
# Method 10: Using bitwise | operator
# ----------------------------------\n
# Python program to print all even no's in a list
 
 
# Defining list with even and odd numbers
# Initializing list 
list1=[39,28,19,45,33,74,56]
 
# Traversing list using for loop
for element in list1:
     
    # condition to check even or not
    if  element|1 != element: 
        print(element,end=' ')
print(' ')
# Method 11: Using reduce method:
# ----------------------------\n
# Using the reduce function from the functools module
from functools import reduce
list1 = [39,28,19,45,33,74,56]
even_numbers = reduce(lambda x, y: x + [y] if y % 2 == 0 else x, list1, [])
for num in even_numbers:
    print(num, end=" ")
    #This code is contributed by Jyothi pinjala
print(' ')
# Method 12: Using numpy.where() method:
# ------------------------------------\n

import numpy as np
  
# given list
list1 = [2, 7, 5, 64, 14]
  
# converting list to numpy array
arr = np.array(list1)
  
# finding even numbers using where() method
even_num = arr[np.where(arr % 2 == 0)]
  
# printing even numbers
print(even_num)
print(' ')
# Method 13: Using itertools.filterfalse method
# ---------------------------------------------\n
# Using the filterfalse function from the itertools module
from itertools import filterfalse
 
# Test list1
list1 = [39, 28, 19, 45, 33, 74, 56]
 
# filtering even number
even_numbers = filterfalse(lambda y: y % 2, list1)
 
# Printing result
for num in even_numbers:
    print(num, end=" ")


print(' ')
# -----------------------------------------------------\n











































