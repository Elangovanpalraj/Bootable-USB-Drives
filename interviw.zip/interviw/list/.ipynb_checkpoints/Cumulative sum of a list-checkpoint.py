# Cumulative sum of a list
# ---------------------------\n
'''
Input : list = [10, 20, 30, 40, 50]
Output : [10, 30, 60, 100, 150]

Input : list = [4, 10, 15, 18, 20]
Output : [4, 14, 29, 47, 67]
'''
# Methods 1
# --------\n
def Cumulative(lists): 
    cu_list = [] 
    length = len(lists) 
    cu_list = [sum(lists[0:x:1]) for x in range(0, length+1)] 
    return cu_list[1:]
 
# Driver Code 
lists = [10, 20, 30, 40, 50] 
print (Cumulative(lists))
print(' ')
# Methods 2
# --------\n

list=[10,20,30,40,50]
new_list=[] 
j=0
for i in range(0,len(list)):
    j+=list[i]
    new_list.append(j) 
     
print(new_list) 
#code given by Divyanshu singh
print(' ')
'''
#  Use itertools module
# -------------------\n
from itertools import accumulate
import operator
 
def cumulative_sum(input_list):
    # Use the accumulate() function to perform a cumulative sum of the elements in the list
    cumulative_sum_iter = accumulate(input_list, operator.add)
    # Convert the iterator to a list and return it
    return list(cumulative_sum_iter)
 
input_list = [10, 20, 30, 40, 50]
output_list = cumulative_sum(input_list)
print(output_list)
print(' ')
'''
#  using numpy.cumsum()
# --------------------\n

import numpy as np
 
def cumulative_sum(input_list):
    # Convert the list to a NumPy array
    input_array = np.array(input_list)
    # Compute the cumulative sum along the first axis of the array
    cumulative_sum_array = np.cumsum(input_array)
    # Convert the NumPy array back to a list and return it
    return cumulative_sum_array.tolist()
 
input_list = [10, 20, 30, 40, 50]
output_list = cumulative_sum(input_list)
print(output_list)
print(' ')
# METHOD 5:Using counter method
# ---------------------------\n
from collections import Counter
 
def cumulative_sum(lst):
    cnt = Counter(lst)
    cum_sum = [lst[0]]
    for i in range(1, len(lst)):
        cum_sum.append(cum_sum[i-1] + lst[i])
    return cum_sum
 
lst = [10, 20, 30, 40, 50]
result = cumulative_sum(lst)
print(result)
print(' ')
# -------------------------------------------------------\n













































































































































