# Remove empty List from List
# --------------------------\n
# methods
# ------n
test_list = [5, 6, [], 3, [], [], 9]
 
# printing original list
print("The original list is : " + str(test_list))
 
# Remove empty List from List
# using list comprehension
res = [ele for ele in test_list if ele != []]
 
# printing result
print("List after empty list removal : " + str(res))
print(' ')
#  Using filter() method
# ---------------------\n
test_list = [5, 6, [], 3, [], [], 9]
 
# Printing original list
print("The original list is : " + str(test_list))
 
# Removing empty List from List
# using filter() method
res = list(filter(None, test_list))
 
# Printing the resultant list
print("List after empty list removal : " + str(res))
print(' ')
# Using function definition
# -------------------------\n

def empty_list_remove(input_list):
    new_list = []
    for ele in input_list:
        if ele:
            new_list.append(ele)
    return new_list
 
 
# input list values
input_list = [5, 6, [], 3, [], [], 9]
 
# print initial list values
print(f"The original list is : {input_list}")
# function-call & print values
print(f"List after empty list removal : {empty_list_remove(input_list)}")
print(' ')
#  Using len() and type() methods
# ---------------------------\n
test_list = [5, 6, [], 3, [], [], 9]
 
# printing original list
print("The original list is : " + str(test_list))
new_list=[]
# Remove empty List from List
for i in test_list:
    x=str(type(i))
    if(x.find('list')!=-1):
        if(len(i)!=0):
            new_list.append(i)
    else:
        new_list.append(i)
# printing result
print("List after empty list removal : " + str(new_list))
print(' ')
# Using remove() method
# ---------------------\n
test_list = [5, 6, [], 3, [], [], 9]
 
# printing original list
print("The original list is : " + str(test_list))
 
# Remove empty List from List
while [] in test_list :
    test_list.remove([])
 
# printing result
print("List after empty list removal : " + str(test_list))
print(' ')
#  Using list(),map(),join() and replace() methods
# -----------------------------------------------\n

test_list = [5, 6, [], 3, [], [], 9]
 
# printing original list
print("The original list is : " + str(test_list))
x=list(map(str,test_list))
y="".join(x)
y=y.replace("[]","")
y=list(map(int,y))
 
# printing result
print("List after empty list removal : " + str(y))
print(' ')
#  Using enumerate function
# ------------------------\n
test_list = [5, 6, [], 3, [], [], 9]
res = [ele for i,ele in enumerate(test_list) if ele != []]
print(res)
print(' ')
# Using filter function
# --------------------\n
test_list = [5, 6, [], 3, [], [], 9]
 
# printing original list
print("The original list is : " + str(test_list))
 
# Remove empty List from List
res = filter(None, test_list)
 
# printing result
print("List after empty list removal : " ,res)
print(' ')
#  Using lambda function
# ----------------------\n
test_list = [5, 6, [], 3, [], [], 9]
 
# Printing original list
print("The original list is : " + str(test_list))
 
# Removing empty List from List
# using lambda function
res = list(filter(lambda x: x != [], test_list))
 
# Printing the resultant list
print("List after empty list removal : " + str(res))
print(' ')
# Using Recursion method
# ---------------------
def remove_empty(start,oldlist,newlist):
  if start==len(oldlist):  #base condition 
    return newlist
  if oldlist[start]==[]:  #checking the element is empty list or not
    pass
  else:
    newlist.append(oldlist[start])   #appending non empty list element to newlist
  return remove_empty(start+1,oldlist,newlist)  #recursive function call
 
test_list = [5, 6, [], 3, [], [], 9]
 
# printing original list
print("The original list is : " + str(test_list))
result=remove_empty(0,test_list,[])
# printing result
print("List after empty list removal : " ,result)
print(' ')
#  Using itertools.filterfalse()
#  ----------------------------\n
import itertools
 
# Initializing list by custom values
test_list = [5, 6, [], 3, [], [], 9]
 
# Printing original list
print("The original list is : " + str(test_list))
 
# Removing empty List from List
# using lambda function
res = list(itertools.filterfalse(lambda x: x == [], test_list))
 
# Printing the resultant list
print("List after empty list removal : " + str(res))
print(' ')
# Using the map() function
# -------------------------\n
test_list = [5, 6, [], 3, [], [], 9]
 
# printing original list
print("The original list is : " + str(test_list))
 
# Remove empty List from List
# using map() function
res = list(map(lambda x: x if x != [] else None, test_list))
res = [x for x in res if x != None]
 
# printing result
print("List after empty list removal : " + str(res))
#This code is contributed by Vinay Pinjala.
print(' ')
# Using re module re
# ---------------\n

# input list values
input_list = [5, 6, [], 3, [], [], 9]
  
# print initial list values
print(f"The original list is : {input_list}")
  
# removing empty list from list
res = list(filter(None, [x for x in input_list if not re.match('\[\]', str(x))]))
  
# print resultant list
print(f"List after empty list removal : {res}")
print(' ')
#  Using the pop()
# --------------\n

test_list = [5, 6, [], 3, [], [], 9]
# Print the original list
print("The original list is : " + str(test_list))
# Counter variable 'i' to keep track of the current index
i = 0
# While loop to go through all elements of the list
while i < len(test_list):
    # If the current element is an empty list, remove it from the list
    if test_list[i] == []:
        test_list.pop(i)
    # Else, increment the counter variable
    else:
        i += 1
# Reassign the result to the original list after removing all empty lists
res = test_list
# Print the result
print("List after empty list removal : " + str(res))
 
 
#This code is contributed by Jyothi pinjala.
print(' ')

# -------------------------------------------------------------\n





























































































































































