# Python program to find sum of elements in list
'''
Example:  

Input: [12, 15, 3, 10]
Output: 40

Input: [17, 5, 3, 5]
Output: 30
'''
# find sum of elements in list
# Python program to find sum of elements in list
 
total = 0
 
# creating a list
list1 = [11, 5, 17, 18, 23]
 
# Iterate each element in list
# and add them in variable total
for ele in range(0, len(list1)):
    total = total + list1[ele]
 
# printing total value
print("Sum of all elements in given list: ", total)
print(' ')
# Using while() loop
# ------------------\n
# Python program to find sum of elements in list
total = 0
ele = 0
 
# creating a list
list1 = [11, 5, 17, 18, 23] 
 
# Iterate each element in list
# and add them in variable total
while(ele < len(list1)):
    total = total + list1[ele]
    ele += 1
     
# printing total value
print("Sum of all elements in given list: ", total)
print(' ')
# Recursive way
# -----------\n
# Python program to find sum of all
# elements in list using recursion
 
# creating a list
list1 = [11, 5, 17, 18, 23]
 
# creating sum_list function
 
 
def sumOfList(list, size):
    if (size == 0):
        return 0
    else:
        return list[size - 1] + sumOfList(list, size - 1)
 
 
# Driver code
total = sumOfList(list1, len(list1))
 
print("Sum of all elements in given list: ", total)
print(' ')
# Using sum() method
# -----------------\n
# Python program to find sum of elements in list
 
# creating a list
list1 = [11, 5, 17, 18, 23]
 
# using sum() function
total = sum(list1)
 
# printing total value
print("Sum of all elements in given list: ", total)
print(' ')
# Using add() function of operator module
# ------------------------------------\n
# Python 3 program to find the sum of all elements in the
# list using add function of operator module
 
from operator import*
list1 = [12, 15, 3, 10]
result = 0
for i in list1:
  # Adding elements in the list using
  # add function of operator module
    result = add(i, result)
# printing the result
print(result)
print(' ')
# Using enumerate function
# ----------------------\n
list1 = [12, 15, 3, 10];s=0
for i,a in enumerate(list1): 
  s+=a 
print(s)
print(' ')
# Using list comprehension
# -----------------------\n
list1 = [12, 15, 3, 10]
s=[i for i in list1] 
print(sum(s))
print(' ')
#  Using lambda function
# ---------------------\n
list1 = [12, 15, 3, 10]
print(sum(list(filter(lambda x: (x),list1))))
print(' ')
#  Using add operator
# ------------------\n
import operator
list1 = [12, 15, 3, 10] ;s=0
for i in list1:
  s=s+operator.add(0,i)
print(s)
print(' ')
# Using add()+while loop
# --------------------\n
# Python program to find sum of elements in the list
# Importing the operator module
import operator
 
# Initializing the values
lst = [0, 4, 1, 6, 8]
sum = 0
i = 0
 
# Traversing the list using while loop finding the sum using add()
while i < len(lst):
    sum = sum+operator.add(0, lst[i])
    i = i+1
 
# printing the sum of list elements
print('The sum of elements in the given list is:', sum)
 
# This code is contributed by SHAIK HUSNA
print(' ')









































