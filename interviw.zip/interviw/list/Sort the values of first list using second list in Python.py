# Sort the values of first list using second list in Python
# ===========================================================\n
'''
Input : list1 = [“a”, “b”, “c”, “d”, “e”, “f”, “g”, “h”, “i”]
           list2 = [ 0,   1,   1,    0,   1,   2,   2,   0,   1]
Output : [‘a’, ‘d’, ‘h’, ‘b’, ‘c’, ‘e’, ‘i’, ‘f’, ‘g’]

Input : list1 = [“g”, “e”, “e”, “k”, “s”, “f”, “o”, “r”, “g”, “e”, “e”, “k”, “s”]
            list2 = [ 0,   1,   1,    0,   1,   2,   2,   0,   1]
Output : [‘g’, ‘k’, ‘r’, ‘e’, ‘e’, ‘g’, ‘s’, ‘f’, ‘o’]
'''
# ===============================================================\n
# the sorted, zipped list.
# ======================\n
# Python program to sort
# one list using
# the other list
 
 
def sort_list(list1, list2):
 
    zipped_pairs = zip(list2, list1)
 
    z = [x for _, x in sorted(zipped_pairs)]
 
    return z
 
 
# driver code
x = ["a", "b", "c", "d", "e", "f", "g", "h", "i"]
y = [0,   1,   1,    0,   1,   2,   2,   0,   1]
 
print(sort_list(x, y))
 
x = ["g", "e", "e", "k", "s", "f", "o", "r", "g", "e", "e", "k", "s"]
y = [0,   1,   1,    0,   1,   2,   2,   0,   1]
 
print(sort_list(x, y))
print(' ')

# Approach 2: By using Dictionary, list comprehension, lambda function
# ==============================================================\n
def sorting_of_element(list1, list2):
 
    # initializing blank dictionary
    f_1 = {}
 
    # initializing blank list
    final_list = []
 
    # Addition of two list in one dictionary
    f_1 = {list1[i]: list2[i] for i in range(len(list2))}
 
    # sorting of dictionary based on value
    f_lst = {k: v for k, v in sorted(f_1.items(), key=lambda item: item[1])}
 
    # Element addition in the list
    for i in f_lst.keys():
        final_list.append(i)
    return final_list
 
 
list1 = ["a", "b", "c", "d", "e", "f", "g", "h", "i"]
list2 = [0,   1,   1,    0,   1,   2,   2,   0,   1]
 
 
list3 = sorting_of_element(list1, list2)
print(list3)
print(' ')
# Approach 3: Using sort(),list() and set() methods
# =================================================\n
# Python program to sort values of first list based on second list
list1 = ["a", "b", "c", "d", "e", "f", "g", "h", "i"]
list2 = [0, 1, 1, 0, 1, 2, 2, 0, 1]
a = list(set(list2))
a.sort()
res = []
for i in a:
    for j in range(0, len(list2)):
        if(list2[j] == i):
            res.append(list1[j])
print(res)
print(' ')
# New Approach : Using collections.OrderedDict()
# ==============================================\n
from collections import OrderedDict
list1 = ["a", "b", "c", "d", "e", "f", "g", "h", "i"]
list2 = [0, 1, 1, 0, 1, 2, 2, 0, 1]
d = OrderedDict(zip(list1, list2))
res = list(OrderedDict(sorted(d.items(), key=lambda x: x[1])))
print(res)
print(' ')
# Approach : Using the numpy.argsort() function with fancy indexing
# ============================================================\n
import numpy as np
 
# Define a function that takes two lists as input, sorts the first list based on
# the order of the second list, and returns the sorted list as a numpy array
def sort_list(list1, list2):
    # Use numpy's argsort function to get the indices that would sort the second list
    idx = np.argsort(list2)
    # Index the first list using the sorted indices and return the result as a numpy array
    return np.array(list1)[idx]
 
# Define two lists of strings and integers to be used as inputs for the sort_list function
x = ["a", "b", "c", "d", "e", "f", "g", "h", "i"]
y = [0, 1, 1, 0, 1, 2, 2, 0, 1]
 
# Call the sort_list function with the two lists and print the result
print(sort_list(x, y))
 
# Define another two lists of strings and integers to be used as inputs for the sort_list function
x = ["g", "e", "e", "k", "s", "f", "o", "r", "g", "e", "e", "k", "s"]
y = [0, 1, 1, 0, 1, 2, 2, 0, 1]
 
# Call the sort_list function with the two lists and print the result
print(sort_list(x, y))
print(' ')
# ============================================================\n



























































































































































