# Different ways to clear a list in Python
# ---------------------------------------------\n
# Using clear()
# Reinitializing the list
# Using “*= 0”
# Using del
# Using pop() method
# Using slicing
# using list comprehension
# --------------------------------------------------------------\n
# List clear()
# ----------\n
GEEK = [6, 0, 4, 1]
print('GEEK before clear:', GEEK)

# Clearing list
GEEK.clear()
print('GEEK after clear:', GEEK)
print(' ')
# Reinitializing the List
# ----------------------\n

list1 = [1, 2, 3]

# Printing list2 before deleting
print("List1 before deleting is : "
      + str(list1))

# deleting list using reinitialization
list1 = []

# Printing list2 after reinitialization
print("List1 after clearing using reinitialization : "
      + str(list1))
print(' ')
# List Using “*= 0”
# ----------------\n
# Initializing lists
list1 = [1, 2, 3]

# Printing list2 before deleting
print("List1 before clearing is : "
      + str(list1))

list1*=0
# Printing list2 after reinitialization
print("List1 after clearing using *=0 : "
      + str(list1))
print(' ')
# List Using del
# -----------=-\n
list1 = [1, 2, 3]
list2 = [5, 6, 7]

# Printing list1 before deleting
print("List1 before deleting is : " + str(list1))

# deleting list1 using del
del list1[:]
print("List1 after clearing using del : " + str(list1))


# Printing list2 before deleting
print("List2 before deleting is : " + str(list2))

# deleting list using del
del list2[:]
print("List2 after clearing using del : " + str(list2))
print(' ')
# pop() method
# -----------\n
list1 = [1, 2, 3]

# Printing list1 before deleting
print("List1 before deleting is : " + str(list1))

# deleting list1
while(len(list1) != 0):
    list1.pop()
print("List1 after clearing using del : " + str(list1))
print(' ')
#  using Slicing
# --------------\n
# Initializing list
lst = [1, 2, 3, 4, 5]

print("List before clearing: ",lst)
# Clearing list using slicing
lst = lst[:0]
print("List after clearing using Slicing: ",lst)
print(' ')
# list comprehension method
# ------------------------\n
def clear_list(lst):
    lst = [item for item in lst if False]
    return lst

input_list = [2, 3, 5, 6, 7]
output = clear_list(input_list)
print(output)  # Output: []
print(' ')
# ------------------------------------------------------------\n







































