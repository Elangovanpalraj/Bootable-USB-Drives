# negative numbers in a list
# ------------------------\n
'''
Input: list1 = [12, -7, 5, 64, -14]
Output: -7, -14

Input: list2 = [12, 14, -95, 3]
Output: -95
'''
# Example #1:
# -----------\n
# Python program to print negative Numbers in a List
 
# list of numbers
list1 = [11, -21, 0, 45, 66, -93]
 
# iterating each number in list
for num in list1:
 
    # checking condition
    if num < 0:
        print(num, end=" ")
print(' ')
# Using while loop
# ----------------\n
# Python program to print negative Numbers in a List
 
# list of numbers
list1 = [-10, 21, -4, -45, -66, 93]
num = 0
 
# using while loop
while(num < len(list1)):
 
    # checking condition
    if list1[num] < 0:
        print(list1[num], end=" ")
 
    # increment num
    num += 1

print(' ')
# Using list comprehension
# -------------------------\n
# Python program to print negative Numbers in a List
 
# list of numbers
list1 = [-10, -21, -4, 45, -66, 93]
 
# using list comprehension
neg_nos = [num for num in list1 if num < 0]
 
print("Negative numbers in the list: ", *neg_nos)
print(' ')
# Using lambda expressions
# -----------------------\n
# Python program to print negative Numbers in a List
 
# list of numbers
list1 = [-10, 21, 4, -45, -66, 93, -11]
 
 
# we can also print negative no's using lambda exp.
neg_nos = list(filter(lambda x: (x < 0), list1))
 
print("Negative numbers in the list: ", *neg_nos)
print(' ')
# Using enumerate function
# ----------------------\n

l=[12, -7, 5, 64, -14]
print([a for j,a in enumerate(l) if a<0])
print(' ')
# Using startswith() method
# ------------------------\n
# Python program to print negative Numbers in a List
 
# list of numbers
list1 = [11, -21, 0, 45, 66, -93]
res = []
list2 = list(map(str, list1))
for i in range(0, len(list2)):
    if(list2[i].startswith("-")):
        res.append(str(list1[i]))
res = " ".join(res)
print(res)
print(' ')
# Using numpy.array
# ---------------\n
# Python program to print negative Numbers in a List
import numpy as np
# list of numbers
list1 = [-10, 21, 4, -45, -66, 93, -11]
 
 
# Using numpy to print the negative number
temp = np.array(list1)
neg_nos = temp[temp <= 0]
 
print("Negative numbers in the list: ", *neg_nos)
print(' ')
# Using Recursion
# ---------------\n
def PrintNegative(itr,list1):
  if itr == len(list1): #base condition
    return
  if list1[itr] < 0: #check negative number or not
    print( list1[itr],end = " ")
  PrintNegative(itr+1,list1) #recursive function call
   
list1 = [-1,8,9,-5,7]
PrintNegative(0,list1)
print(' ')
# Using numpy.array() and numpy.where()
# -------------------------------\n
import numpy as np
 
# list of numbers
list1 = [12, -7, 5, 64, -14]
 
# converting list to numpy array
arr1 = np.array(list1)
 
# finding negative numbers in the array
neg_nums = arr1[np.where(arr1 < 0)]
 
# printing negative numbers
print("Negative numbers in the list: ", *neg_nums)
print(' ')
# Using functools.reduce
# ---------------------\n

from functools import reduce
 
# list of numbers
list1 = [-10, -21, -4, 45, -66, 93]
 
# using reduce method
neg_nos = reduce(lambda a, b : a + [ b ] if b < 0 else a ,list1, [])
 
print("Negative numbers in the list: ", *neg_nos)
print(' ')
# -----------------------------------------------------\n






















































































































