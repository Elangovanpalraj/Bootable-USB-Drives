# Check if element exists in list in Python
# -----------------------------------------\n
# Input: test_list = [1, 6, 3, 5, 3, 4]
# 3  # Check if 3 exist or not.
# Output: True
# Explanation: The output is True because the element we are looking is exist in the list.
# --------------------------------------------------------------------------------------\n
# type
# -----\n
# Using “in” Statement 
# Using a loop 
# Using any() function
# Using count() function
# Using sort with bisect_left and set()
# Using find() method
# Using Counter() function
# Using try-except block
# --------------------------\n
# Using “in” Statement
# --------------------\n
lst = [21,4,8,6,5,56,89]
i = 4
if i in lst:
    print('exist')
else:
    print('not exist')

print(' ')
test = [1,3,6,7,9,4]
result = any(item in test for item in test)
print('Does string contain any list element:' + str (bool(result)))
print(' ')
# Using count() function
# ---------------------\n

test1 = [10, 15, 20, 7, 46, 2808]
print("checking if 20 exists in list")
exist_count = test1.count(20)
if exist_count > 0:
    print("yes, 20 exists in list")

else:
    print("No,20 does not exists in list")

print(' ')
# the list using a loop
# --------------------\n
# Initializing list
test_list = [1, 6, 3, 5, 3, 4]

# Checking if 4 exists in list
for i in test_list:
    if(i == 4):
        print("Element Exists")
print(' ')
# the list using any()
# -------------------\n
# Initializing list
test_list = [1, 6, 3, 5, 3, 4]

result = any(item in test_list for item in test_list)
print("Does string contain any list element : " +str(bool(result)))
print(' ')
# the list using sort with bisect_left and set
# --------------------------------------------\n
from bisect import bisect_left , bisect
test_list_set = [ 1, 6, 3, 5, 3, 4 ]
test_list_bisect = [ 1, 6, 3, 5, 3, 4 ]
print("Checking if 4 exists in list ( using set() + in) : ")
test_list_set = set(test_list_set)
if 4 in test_list_set :
    print ("Element Exists")

print("Checking if 4 exists in list ( using sort() + bisect_left() ) : ")
# Checking if 4 exists in list 
# using sort() + bisect_left()
test_list_bisect.sort()
if bisect_left(test_list_bisect, 4)!=bisect(test_list_bisect, 4):
    print ("Element Exists")
else:
    print("Element doesnt exist")

print(' ')
# list using find() method
# ------------------------\n
# Initializing list
test_list = [10, 15, 20, 7, 46, 2808]

print("Checking if 15 exists in list")
x=list(map(str,test_list))
y="-".join(x)

if y.find("15") !=-1:
    print("Yes, 15 exists in list")
else:
    print("No, 15 does not exists in list")
print(' ')
# list using Counter() function
# ----------------------------\n
from collections import Counter

test_list = [10, 15, 20, 7, 46, 2808]

# Calculating frequencies
frequency = Counter(test_list)

# If the element has frequency greater than 0
# then it exists else it doesn't exist
if(frequency[15] > 0):
    print("Yes, 15 exists in list")
else:
    print("No, 15 does not exists in list")

print(' ')
#  list using try-except block
# --------------------------\n
def element_exists(lst, element):
  # Try to get the index of the element in the list
  try:
    lst.index(element)
  # If the element is found, return True
    return True
  # If a ValueError is raised, the element is not in the list
  except ValueError:
  # Return False in this case
    return False

#Test the function
test_list = [1, 6, 3, 5, 3, 4]

print(element_exists(test_list, 3)) # prints True
print(element_exists(test_list, 7)) # prints False
#This code is contributed by Edula Vinay Kumar Reddy
print(' ')
# list using filter() Function
# ----------------------------\n
my_list = [1, 2, 3, 4, 5]
element_to_check = 3

# Use filter to create an iterator of elements equal to the target element
filtered_elements = filter(lambda x: x == element_to_check, my_list)

# Convert the iterator to a list and check if it's not empty
if list(filtered_elements):
    print("Element exists in the list")
else:
    print("Element does not exist in the list")
print(' ')
# ----------------------------------------------\n



















        
