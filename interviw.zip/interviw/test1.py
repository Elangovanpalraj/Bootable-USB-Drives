# remove methods
# ============\n
# Using enumerate, join
# ==================\n
'''
def remove(string,i):
    
    return "".join()
    
print(remove("elangovan",4))

def remove(string, i): 
  return "".join() 
  
print(remove("geeksforgeeks",2)) 
'''
#============================================================================\n
import re
s= 'elang mani adhi'
print(re.findall(r'[a-zA-Z]+',s))
print("_".join(re.findall(r'[a-zA-Z]+',s)))
#==============================================\n
import re
test= 'Geeksforgeeks is best for geets and cs'
print('the original string is :'+ str(test))
words=['best','for','cs']
replace= 'pe'
res= re.sub('|'.join(sorted(words,key=len,reverse = True)),replace,test)
print('string after multiple replace:'+ str(res))
# =================================================================\
'''
the original string is :Geeksforgeeks is best for geets and cs
string after multiple replace:Geekspegeeks is pe pe geets and p
'''
# ============================================================================\n
# Python | Permutation of a given string using inbuilt function
# ==================================================\n
'''
Input :  str = 'ABC'
Output : ABC 
         ACB 
         BAC 
         BCA 
         CAB 
         CBA
# ===============\n
import string
from itertools import permutation
pe= 'elan'
a= string.ascii_letter
p= permutation(pe)
e=[]
for i in list(p):
    if(i not in e ):
        e.append(i)
        print(''.join(i))
'''
# ========================================================================================\n


# Python code to find the URL from an input string
 
def Find(string):
    x=string.split()
    res=[]
    for i in x:
        if i.startswith("https:") or i.startswith("http:"):
            res.append(i)
    return res
             
# Driver Code
string = 'My Profile: https://auth.geeksforgeeks.org/user/Chinmoy%20Lenka/articles in the portal of https://www.geeksforgeeks.org/'
print("Urls: ", Find(string))
# ==============================================================================================================\n

















