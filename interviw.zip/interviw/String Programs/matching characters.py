# Count the Number of matching characters in a pair of string
# ========================================================\n
'''
Input : str1 = 'abcdef'
        str2 = 'defghia'
Output : 4 
(i.e. matching characters :- a, d, e, f)

Input : str1 = 'aabcddekll12@'
        str2 = 'bb2211@55k'
Output : 5 
(i.e. matching characters :- b, 1, 2, @, k)

'''
# that concept of set(intersection)
# ================================\n
def commonfun(str1,str2):
    return(len((set(str1)).intersection(set(str2))))


string1="VISHAV"
string2="VANSHIKA"


no_of_common_character=commonfun(string1.lower(),string2.lower())

print("NO. OF COMMON CHRACTERS ARE : ",no_of_common_character)
