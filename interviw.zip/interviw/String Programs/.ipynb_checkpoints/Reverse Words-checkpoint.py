# Reverse Words
# =============\n
'''
Input : str =" geeks quiz practice code"
Output : str = code practice quiz geeks  
Input : str = "my name is laxmi"
output : str= laxmi is name my 
'''
# Reverse Words Using backward Iteration
# ======================================\n
import re
def rev_sentence(sentence):
 
    words = re.findall('\w+', sentence)
 
    reverse_sentence = ' '.join(words[i] for i in range(len(words)-1, -1, -1))
 
    return reverse_sentence
 
if __name__ == "__main__":
    input = 'geeks quiz practice code'
    print (rev_sentence(input))
