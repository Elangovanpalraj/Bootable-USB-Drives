# Remove all duplicates from a given string
# ====================================\n
'''
Input : geeksforgeeks 
Output : geksfor
'''
# Methods : fromkeys(seq[, value])
# ==============================\n

from collections import OrderedDict
seq = ('name', 'age', 'gender')
dict = OrderedDict.fromkeys(seq)
 
print (str(dict)) 
dict = OrderedDict.fromkeys(seq, 10)
 

print (str(dict))       
