# Least Frequent Character in String
# ====================================\n
# Method : Using numpy
# ====================\n
import numpy as np
def least_frequent_char(string):
    freq = {char: string.count(char) for char in set(string)}
    return list(freq.keys())[np.argmin(list(freq.values()))]
# Example usage
input_string = "GeeksforGeeks"
min_char = least_frequent_char(input_string)
print("The original string is:", input_string)
print("The minimum of all characters in", input_string, "is:", min_char)
#This code is contributed by Jyothi Pinjala.
