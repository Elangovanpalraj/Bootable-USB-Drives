# Maximum frequency character in String
# ======================================\n
# Method 4: Using a generator expression
# ====================================\n
test_str = "GeeksforGeeks"
res = max(test_str, key=lambda x: test_str.count(x))
print(res)
