# even length words in a string
# ============================\n
'''
Input: s = "This is a python language"
Output: This is python language

Input: s = "i am laxmi"
Output: am
'''
# Using the itertools.filterfalse() function
# =========================================\n
import itertools
s="geeks for geek"
 

words = s.split(" ")
 

even_length_words = list(itertools.filterfalse(lambda x: len(x) % 2 != 0, words))
 

print(even_length_words)
