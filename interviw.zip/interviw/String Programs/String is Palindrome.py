# String is Palindrome or Not
# ==========================\n
'''
Input : malayalam
Output : Yes

Input : geeks
Output : No
'''
#  String is Palindrome using recursion
# =====================================\n
def isPalindrome(s):
    s = s.lower()
    l = len(s)
 
    if l < 2:
        return True
 
    elif s[0] == s[l - 1]:
 
        return isPalindrome(s[1: l - 1])
 
    else:
        return False
 
s = "MalaYaLam"
ans = isPalindrome(s)
 
if ans:
    print("Yes")
 
else:
    print("No")
