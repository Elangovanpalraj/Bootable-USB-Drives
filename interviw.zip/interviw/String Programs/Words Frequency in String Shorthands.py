#  Words Frequency in String Shorthands
# ===================================\n
'''
Input : test_str = 'Gfg is best' 
Output : {'Gfg': 1, 'is': 1, 'best': 1} 
Input : test_str = 'Gfg Gfg Gfg' 
Output : {'Gfg': 3}
'''
# sing dictionary comprehension + operator.countOf() + split()
# ========================================================\n
import operator as op
 
test_str = 'Gfg is best . Geeks are good and Geeks like Gfg'
 
print("The original string is : " + str(test_str))
listString = test_str.split()

res = {key: op.countOf(listString, key) for key in listString}
 
print("The words frequency : " + str(res))
