#  Convert Snake case to Pascal case
# ===============================\ n
'''
Input : geeks_for_geeks
Output : GeeksforGeeks
Input : left_index
Output : leftIndex
'''
# using reduce():
# ==============\n
from functools import reduce
 

test_str = 'geeksforgeeks_is_best'
 

print("The original string is : " + test_str)


res = reduce(lambda a, b: a + b.title(), test_str.split("_"), "")
 

print("The String after changing case : " + str(res))
