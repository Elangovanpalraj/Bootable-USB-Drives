# Symmetrical or Palindrome
# =========================\n
'''
Input: khokho
Output: 
The entered string is symmetrical
The entered string is not palindrome

Input:amaama
Output:
The entered string is symmetrical
The entered string is palindrome
'''
# Using re module
# ============\n
import re

input_str = "amaama"
reversed_str = input_str[::-1]

if input_str == reversed_str:
    print("The entered string is symmetrical")
else:
    print("The entered string is not symmetrical")

if re.match("^(\w+)\Z", input_str) and input_str == input_str[::-1]:
    print("The entered string is palindrome")
else:
    print("The entered string is not palindrome")
    
