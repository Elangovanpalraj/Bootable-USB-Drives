#  Remove Letters
# ================\n
'''
Input: 'Geeks123For123Geeks' 
Output: GeeksForGeeks
Explanation: In This, we have removed the '123' character from a string.
'''
# Typy
# ===\n

# Using str.replace()
# Using translate()
# Using recursion
# Using Native Method
# Using slice + concatenation
# Using str.join()
# Using bytearray
# Using removeprefix()
# ====================================================\n
#  Python Using bytearray
# =====================\n
def remove_char(s, i):
    b = bytearray(s, 'utf-8')
    del b[i]
    return b.decode()
 
s = "elangovan"
i = 4
s = remove_char(s, i)
print(s)
