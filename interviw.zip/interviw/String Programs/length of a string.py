# Find length of a string in python (6 ways)
# =========================================\n
'''
Input : 'abc'
Output : 3

Input : 'hello world !'
Output : 13

Input : ' h e l   l  o '
Output :14
'''
# Using reduce method
# ===================\n


import functools
 
def findLen(string):
    return functools.reduce(lambda x,y: x+1, string, 0)
 
 

string = 'geeks'
print(findLen(string))
