
from datetime import date,timedelta
date1=date(2024,4,27)
date2=date(2024,4,30)
delta =timedelta(days=1)
dates = []
while date1 <=date2:
    dates.append(date1.isoformat())
    date1 +=delta
print('Dates between',date1,'and',date2)
print(dates)

