# Adding and Subtracting Matrices in Python
# ========================================\n
'''
Suppose we have two matrices A and B.
A = [[1,2],[3,4]]
B = [[4,5],[6,7]]

then we get
A+B = [[5,7],[9,11]]
A-B = [[-3,-3],[-3,-3]]
'''
# used np.add() method
# ===================\n
import numpy as np
 
 
# creating first matrix
A = np.array([[1, 2], [3, 4]])
 
# creating second matrix
B = np.array([[4, 5], [6, 7]])
 
print("Printing elements of first matrix")
print(A)
print("Printing elements of second matrix")
print(B)
 
# adding two matrix
print("Addition of two matrix")
print(np.add(A, B))
