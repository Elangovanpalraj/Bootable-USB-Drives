# Matrix Product
# =================\n
# Using extend() method
# =====================\n
test_list = [[1, 4, 5], [7, 3], [4], [46, 7, 3]]
 
print("The original list : " + str(test_list))
 
x = []
for i in test_list:
    x.extend(i)
res = 1
for j in x:
    res *= j
 
print("The total element product in lists is : " + str(res))
