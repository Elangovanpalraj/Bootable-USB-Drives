# Get Kth column of Matrix
# ========================\n
# Using numpy
import numpy as np
test1 = [[4,5,6,],[8,3,6],[34,65,78]]
print('original list:' + str(test1))
K=2
res = np.array(test1)[:,K]
print('K th column of matrix is :' + str(res))
