# Matrix creation of n*n
# =====================\n
# Method : Using nested for loop
# ==============================\n
N = 4
print("The dimension : " + str(N))
 
res = []
for i in range(N):
  row = []
  for j in range(N):
    row.append(1 + N * i + j)
  res.append(row)
 
print("The created matrix of N * N: " + str(res))
