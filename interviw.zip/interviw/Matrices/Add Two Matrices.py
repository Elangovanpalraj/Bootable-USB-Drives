# Add Two Matrices
# ===============\n
'''
Input :
 X= [[1,2,3],
    [4 ,5,6],
    [7 ,8,9]]
 
Y = [[9,8,7],
    [6,5,4],
    [3,2,1]]
 
Output :
 result= [[10,10,10],
         [10,10,10],
         [10,10,10]]
'''
# Add Two Matrices Using for loop
# ==============================\n
# Program to add two matrices using nested loop
 
X = [[1,2,3],
    [4 ,5,6],
    [7 ,8,9]]
 
Y = [[9,8,7],
    [6,5,4],
    [3,2,1]]
 
 
result = [[0,0,0],
        [0,0,0],
        [0,0,0]]
 
# iterate through rows
for i in range(len(X)):   
# iterate through columns
    for j in range(len(X[0])):
        result[i][j] = X[i][j] + Y[i][j]
 
for r in result:
    print(r)
print(' ')
# Add Two Matrices Using zip() function
# =====================================\n
X = [[1,2,3],
    [4 ,5,6],
    [7 ,8,9]]
  
Y = [[9,8,7],
    [6,5,4],
    [3,2,1]]
 
result = [map(sum, zip(*t)) for t in zip(X, Y)]
  
print(result)
print(' ')
# Add Two Matrices Using Numpy
# ============================\n
import numpy as np
  
X = [[1,2,3],
    [4 ,5,6],
    [7 ,8,9]]
  
Y = [[9,8,7],
    [6,5,4],
    [3,2,1]]
 
result = np.array(X) + np.array(Y)
 
print(result)
# ========================================================\n



























































































